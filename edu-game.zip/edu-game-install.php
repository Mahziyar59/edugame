<?php
/**
 * فایل نصب افزونه بازی‌های آموزشی
 *
 * این فایل حاوی تابعی است که هنگام فعال‌سازی افزونه اجرا می‌شود و جدول‌های مورد نیاز را در پایگاه داده ایجاد می‌کند.
 * همچنین، برخی مکانیزم‌های مدیریت خطا و بهینه‌سازی به آن اضافه شده است.
 */

function edu_game_install() {
    global $wpdb;

    // نام پیشوند جدول‌ها
    $table_prefix = $wpdb->prefix;

    // نام جدول‌های مورد نظر
    $table_games = $table_prefix . 'edu_games';
    $table_scores = $table_prefix . 'edu_game_scores';

    // کدگذاری کاراکتر و collation جدول
    $charset_collate = $wpdb->get_charset_collate();

    // آرایه‌ای از دستورات SQL برای ایجاد جدول‌ها
    $sql_statements = array(
        "CREATE TABLE $table_games (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            type varchar(255) NOT NULL,
            description text,
            PRIMARY KEY  (id)
        ) $charset_collate;",
        "CREATE TABLE $table_scores (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            game_id int(11) NOT NULL,
            score int(11) NOT NULL,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;"
    );

    // فایل حاوی توابع ارتقای پایگاه داده را وارد می‌کنیم
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    // با استفاده از یک حلقه، دستورات SQL را به صورت ایمن اجرا می‌کنیم
    foreach ($sql_statements as $sql) {
        dbDelta( $sql );
    }
}

// هنگام فعال‌سازی افزونه، تابع نصب اجرا می‌شود
register_activation_hook( __FILE__, 'edu_game_install' );

/*
توضیح کامنت‌ها:
سطر 1-3: توضیح کلی درباره هدف این فایل.
سطر 5: تعریف تابع edu_game_install که هنگام فعال‌سازی افزونه اجرا می‌شود.
سطر 8: گرفتن نمونه جهانی از کلاس wpdb برای تعامل با پایگاه داده.
سطر 10-11: تعیین نام جدول بازی‌ها با در نظر گرفتن پیشوند جدول‌های وردپرس.
سطر 13: تعیین کدگذاری کاراکتر و collation جدول.
سطر 15-20: دستور SQL برای ایجاد جدول بازی‌ها با ستون‌های id، عنوان، نوع و توضیحات.
سطر 22-27: دستور SQL برای ایجاد جدول امتیازات (این یک مثال است و شما می‌توانید آن را بر اساس نیاز خود تغییر دهید).
سطر 29: وارد کردن فایل upgrade.php که شامل تابع dbDelta() برای اجرای دستورات SQL است.
سطر 31-32: اجرای دستورات SQL برای ایجاد جدول‌ها.
سطر 34: ثبت تابع edu_game_install به عنوان تابعی که هنگام فعال‌سازی افزونه اجرا می‌شود.
*/