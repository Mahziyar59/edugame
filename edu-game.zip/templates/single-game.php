<?php
/**
 * قالب صفحه نمایش یک بازی خاص
 */

// دریافت شناسه بازی از URL
$gameId = get_query_var('game_id');

// دریافت اطلاعات بازی از کلاس EduGame
$eduGame = new EduGame();
$game = $eduGame->getGameById($gameId);

// نمایش عنوان بازی
echo '<h1>' . $game->getTitle() . '</h1>';

// نمایش توضیحات بازی
echo '<p>' . $game->getDescription() . '</p>';

// نمایش بازی
switch ($game->getType()) {
    case 'memory':
        // فراخوانی فایل قالب بازی حافظه
        get_template_part('templates/games/memory', 'game');
        break;
    case 'puzzle':
        // فراخوانی فایل قالب بازی پازل
        get_template_part('templates/games/puzzle', 'game');
        break;
    // ... سایر بازی‌ها
}