
<h2><?php echo esc_html($game_data['title']); ?></h2>
<div class="puzzle-container">
    </div>