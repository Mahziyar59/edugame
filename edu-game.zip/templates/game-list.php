<?php
/**
 * قالب لیست بازی‌ها
 */

// دریافت اطلاعات بازی‌ها از کلاس EduGame
$eduGame = new EduGame();
$games = $eduGame->getAllGames();
?>

<h2>لیست بازی‌های آموزشی</h2>

<ul class="game-list">
    <?php foreach ($games as $game): ?>
        <li>
            <a href="<?php echo get_permalink(get_page_by_path('play/' . $game->getId())); ?>">
                <img src="<?php echo get_the_post_thumbnail_url($game->getId()); ?>" alt="<?php echo $game->getTitle(); ?>">
                <h3><?php echo $game->getTitle(); ?></h3>
                <p><?php echo $game->getDescription(); ?></p>
            </a>
        </li>
    <?php endforeach; ?>
</ul>