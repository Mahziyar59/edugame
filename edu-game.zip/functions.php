<?php
// فایل: functions.php

function edugame_load_textdomain() {
    load_plugin_textdomain(
        'edu-game',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
}
add_action('plugins_loaded', 'edugame_load_textdomain');

function edugame_display_notice($message, $type = 'success') {
    // بررسی نوع پیام و استفاده از کلاس مناسب
    $class = ($type === 'error') ? 'notice notice-error' : 'notice notice-success';
    echo "<div class='$class'><p>$message</p></div>";
}

// مثال استفاده از تابع
add_action('admin_notices', function() {
    edugame_display_notice('نوشته با موفقیت ذخیره شد.');
});