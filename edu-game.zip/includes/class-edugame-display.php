<?php
class EduGame_Display {
    public function show_game($game_id, $game_type) {
        // بازی را از پایگاه داده دریافت کنید
        $game = $this->get_game_by_id($game_id);
        // قالب مناسب را بر اساس نوع بازی بارگذاری کنید
		defined('EDUGAME_PLUGIN_DIR') || define('EDUGAME_PLUGIN_DIR', plugin_dir_path(__FILE__));
		$template_file = locate_template('edu-game/templates/game-' . $game_type . '.php', false, EDUGAME_PLUGIN_DIR);
        
        if (!$template_file) {
            return 'قالب بازی یافت نشد.';
        }

        // متغیرهای مورد نیاز را به قالب ارسال کنید
        $game_data = array(
            'title' => $game->title,
            'description' => $game->description,
            // ... سایر داده‌های بازی
        );

        // قالب را نمایش دهید
        ob_start();
        include $template_file;
        return ob_get_clean();
    }

    private function get_game_by_id($game_id) {
        // ... کد برای دریافت اطلاعات بازی از پایگاه داده
    }
}