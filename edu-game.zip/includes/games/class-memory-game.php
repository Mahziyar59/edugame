<?php

namespace EduGame;

class MemoryGame extends Game {
    private $cards; // آرایه‌ای برای نگهداری کارت‌ها
    private $matchedPairs; // تعداد جفت‌های پیدا شده

    public function __construct() {
        parent::__construct();
        // ایجاد کارت‌ها و سایر تنظیمات اولیه
    }

    public function startGame() {
        // شروع بازی
    }

    public function flipCard($cardId) {
        // برگرداندن کارت
    }

    public function checkMatch() {
        // بررسی تطابق دو کارت
    }

    public function isGameOver() {
        // بررسی پایان بازی
    }

    // سایر متدهای مورد نیاز
}