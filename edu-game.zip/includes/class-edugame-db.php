<?php
class EduGame_DB {
    private static $instance = null;
    private $pdo;
    private $table_name;

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'edu_game_scores';

        // اتصال به پایگاه داده با استفاده از PDO و تنظیمات خطای دقیق
        try {
            $this->pdo = new PDO("mysql:host={$wpdb->dbhost};dbname={$wpdb->dbname}", $wpdb->dbuser, $wpdb->dbpassword);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            // مدیریت خطای اتصال به پایگاه داده
            trigger_error("خطای اتصال به پایگاه داده: " . $e->getMessage(), E_USER_ERROR);
        }

        // بررسی و ایجاد جدول در صورت لزوم
        $this->create_table();
    }

    private function create_table() {
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            game_id int(11) NOT NULL,
            score int(11) NOT NULL,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->pdo->exec($sql);
    }

    public function get_scores($user_id) {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table_name} WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function save_score($user_id, $score) {
        $stmt = $this->pdo->prepare("INSERT INTO {$this->table_name} (user_id, score, timestamp) VALUES (:user_id, :score, NOW())");
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':score', $score, PDO::PARAM_INT);
        $stmt->execute();
    }
}